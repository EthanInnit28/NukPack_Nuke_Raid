names = ["Fucked By NukPackSQ", "On Top", "LOL", "🟪", "🤡","🖕" ]
message = """
# @everyone FUCKED BY NukPackSQ

## NuKPack

discord.com/invite/G9DU8xtHT8

"""
token = ""